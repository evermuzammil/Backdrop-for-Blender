bl_info = {
    "name": "Backdrop",
    "author": "Muzammil Halimov",
    "version": (3, 5),
    "blender": (5, 1, 0),
    "location": "View3D > Sidebar > Backdrop",
    "description": "One click Cyclorama",
    "category": "Add Mesh",
}

import bpy
from mathutils import Vector

class OBJECT_OT_create_backdrop(bpy.types.Operator):
    """Create a cyclorama with smooth top wall curve"""
    bl_idname = "object.create_backdrop"
    bl_label = "Create Backdrop"
    bl_options = {'REGISTER', 'UNDO'}

    width: bpy.props.FloatProperty(name="Width", default=10.0, min=0.1)
    depth: bpy.props.FloatProperty(name="Depth", default=10.0, min=0.1)
    height: bpy.props.FloatProperty(name="Height", default=6.0, min=0.1)
    bevel_size: bpy.props.FloatProperty(name="Curve Size", default=2.0, min=0.01)
    left_wall: bpy.props.BoolProperty(name="Left Wall", default=False)
    right_wall: bpy.props.BoolProperty(name="Right Wall", default=False)
    top_wall: bpy.props.BoolProperty(name="Top Wall", default=False)
    floor_only: bpy.props.BoolProperty(name="Floor Only", default=False)
    shadow_catcher: bpy.props.BoolProperty(name="Shadow Catcher", default=False)

    # Hidden properties to lock the snap position on the first button press.
    # Without these, every parameter tweak re-runs execute() and recalculates
    # the position from the Backdrop itself (since it became the active object),
    # causing the backdrop to drift lower each time.
    _snap_x: bpy.props.FloatProperty(default=0.0, options={'HIDDEN'})
    _snap_y: bpy.props.FloatProperty(default=0.0, options={'HIDDEN'})
    _snap_z: bpy.props.FloatProperty(default=0.0, options={'HIDDEN'})

    def invoke(self, context, event):
        # invoke() is called ONLY on the initial button press, not on re-runs.
        # So we capture the snap position here, once, then hand off to execute().
        active_obj = context.active_object
        if active_obj and active_obj.type == 'MESH':
            mw = active_obj.matrix_world
            bottom_z = min([(mw @ Vector(v))[2] for v in active_obj.bound_box])
            self._snap_x = active_obj.location.x
            self._snap_y = active_obj.location.y
            self._snap_z = bottom_z
        else:
            self._snap_x, self._snap_y, self._snap_z = 0.0, 0.0, 0.0
        return self.execute(context)

    def execute(self, context):
        # 1. POSITIONING - use the position locked in invoke(), stays stable on re-runs
        target_pos = Vector((self._snap_x, self._snap_y, self._snap_z))

        # 2. MESH CONSTRUCTION
        w, d, h = self.width / 2, self.depth / 2, self.height
        mesh = bpy.data.meshes.new("BackdropMesh")
        obj = bpy.data.objects.new("Backdrop", mesh)
        context.collection.objects.link(obj)
        obj.location = target_pos

        # Base vertices
        verts = [(-w, -d, 0), (w, -d, 0), (w, d, 0), (-w, d, 0)] # 0,1,2,3
        faces = [(0, 1, 2, 3)]

        if not self.floor_only:
            # Back Wall
            verts.extend([(w, d, h), (-w, d, h)]) # 4, 5
            faces.append((3, 2, 4, 5))
            
            # Side Walls
            if self.left_wall:
                v_idx = len(verts)
                verts.append((-w, -d, h)) # 6
                faces.append((0, 3, 5, v_idx))
                
            if self.right_wall:
                v_idx = len(verts)
                verts.append((w, -d, h)) # 7 (or 6 if no left wall)
                r_wall_idx = 7 if self.left_wall else 6
                faces.append((2, 1, r_wall_idx, 4))
                
            # Top Wall (Connected to Back Wall top edge: 5, 4)
            if self.top_wall:
                t_idx = len(verts)
                verts.extend([(-w, -d, h), (w, -d, h)]) # New top edge
                faces.append((5, 4, t_idx + 1, t_idx))
        
        mesh.from_pydata(verts, [], faces)
        mesh.update()

        # 3. SHADING & CURVE
        for poly in mesh.polygons:
            poly.use_smooth = True

        if not self.floor_only:
            bev = obj.modifiers.new(name="BackdropCurve", type='BEVEL')
            bev.width = self.bevel_size
            bev.segments = 32
            bev.limit_method = 'ANGLE'
            # 30 degrees limit ensures it catches the top wall bend correctly
            bev.angle_limit = 0.523599 

        # 4. PROPERTIES & MATERIAL
        obj.is_shadow_catcher = self.shadow_catcher
        mat = bpy.data.materials.get("Backdrop_Material") or bpy.data.materials.new(name="Backdrop_Material")
        mat.use_nodes = True
        bsdf = mat.node_tree.nodes.get("Principled BSDF")
        if bsdf:
            bsdf.inputs[0].default_value = context.scene.backdrop_color
        
        if not obj.data.materials:
            obj.data.materials.append(mat)
        else:
            obj.data.materials[0] = mat

        # Finalize Selection
        bpy.ops.object.select_all(action='DESELECT')
        context.view_layer.objects.active = obj
        obj.select_set(True)

        return {'FINISHED'}

class VIEW3D_PT_backdrop_panel(bpy.types.Panel):
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Backdrop"
    bl_label = "Backdrop"

    def draw(self, context):
        layout = self.layout
        col = layout.column(align=True)
        col.prop(context.scene, "backdrop_color", text="Color")
        col.separator()
        col.operator("object.create_backdrop", text="Create Backdrop", icon='SURFACE_NCURVE')
        
        layout.separator()
        row = layout.row()
        row.scale_y = 0.6
        row.label(text="Tip: Select object to snap to base.", icon='INFO')

def register():
    bpy.utils.register_class(OBJECT_OT_create_backdrop)
    bpy.utils.register_class(VIEW3D_PT_backdrop_panel)
    bpy.types.Scene.backdrop_color = bpy.props.FloatVectorProperty(
        name="Color", subtype='COLOR', default=(0.8, 0.8, 0.8, 1.0), size=4,
        min=0.0, max=1.0)

def unregister():
    bpy.utils.unregister_class(OBJECT_OT_create_backdrop)
    bpy.utils.unregister_class(VIEW3D_PT_backdrop_panel)
    del bpy.types.Scene.backdrop_color

if __name__ == "__main__":
    register()
